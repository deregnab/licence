#!/bin/sh

./multif

./race

./observation

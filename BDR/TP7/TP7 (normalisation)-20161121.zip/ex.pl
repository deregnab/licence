schema([a,b,c,d,e,f,h]).

fds([ [[a],[d]], [[a,e],[h]], [[d,f],[b,c]], 
      [[e],[c]], [[h],[e]] ]).

answer(K) :- schema(R),fds(F), candkey(R,F,K).